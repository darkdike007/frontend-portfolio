(() => {
var exports = {};
exports.id = 387;
exports.ids = [387];
exports.modules = {

/***/ 225:
/***/ ((module) => {

// Exports
module.exports = {
	"style": {"fontFamily":"'__Nunito_b7da70', '__Nunito_Fallback_b7da70'","fontStyle":"normal"},
	"className": "__className_b7da70"
};


/***/ }),

/***/ 645:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
// ESM COMPAT FLAG
__webpack_require__.r(__webpack_exports__);

// EXPORTS
__webpack_require__.d(__webpack_exports__, {
  "default": () => (/* binding */ aboutMe),
  "getServerSideProps": () => (/* binding */ getServerSideProps)
});

// EXTERNAL MODULE: ./node_modules/react/jsx-runtime.js
var jsx_runtime = __webpack_require__(893);
// EXTERNAL MODULE: ./node_modules/next/font/google/target.css?{"path":"src\\pages\\about-me\\index.tsx","import":"Nunito","arguments":[{"subsets":["latin"]}],"variableName":"nunito"}
var target_path_src_pages_about_me_index_tsx_import_Nunito_arguments_subsets_latin_variableName_nunito_ = __webpack_require__(225);
var target_path_src_pages_about_me_index_tsx_import_Nunito_arguments_subsets_latin_variableName_nunito_default = /*#__PURE__*/__webpack_require__.n(target_path_src_pages_about_me_index_tsx_import_Nunito_arguments_subsets_latin_variableName_nunito_);
// EXTERNAL MODULE: external "flowbite-react"
var external_flowbite_react_ = __webpack_require__(532);
// EXTERNAL MODULE: external "react-circular-progressbar"
var external_react_circular_progressbar_ = __webpack_require__(400);
;// CONCATENATED MODULE: external "react-icons/hi"
const hi_namespaceObject = require("react-icons/hi");
;// CONCATENATED MODULE: external "react-icons/io"
const io_namespaceObject = require("react-icons/io");
// EXTERNAL MODULE: external "next/head"
var head_ = __webpack_require__(968);
var head_default = /*#__PURE__*/__webpack_require__.n(head_);
;// CONCATENATED MODULE: ./src/pages/about-me/index.tsx







function aboutMe({ dataKeahlian , dataSkill , dataDeskripsiDiri , dataPendidikan  }) {
    const keahlianData = dataKeahlian.data;
    const skillData = dataSkill.data;
    const deskripsiDiriData = dataDeskripsiDiri.data;
    const pendidikanData = dataPendidikan.data;
    const percentage = 66;
    return /*#__PURE__*/ (0,jsx_runtime.jsxs)(jsx_runtime.Fragment, {
        children: [
            /*#__PURE__*/ (0,jsx_runtime.jsxs)((head_default()), {
                children: [
                    /*#__PURE__*/ jsx_runtime.jsx("title", {
                        children: "About Me | My Portfolio"
                    }),
                    /*#__PURE__*/ jsx_runtime.jsx("meta", {
                        name: "description",
                        content: "Halaman yang lebih detail tentang saya"
                    })
                ]
            }),
            /*#__PURE__*/ (0,jsx_runtime.jsxs)(external_flowbite_react_.Navbar, {
                fluid: true,
                className: `w-full py-5 text-slate-700 ${(target_path_src_pages_about_me_index_tsx_import_Nunito_arguments_subsets_latin_variableName_nunito_default()).className}`,
                children: [
                    /*#__PURE__*/ jsx_runtime.jsx(external_flowbite_react_.Navbar.Brand, {
                        href: "/",
                        children: /*#__PURE__*/ jsx_runtime.jsx("span", {
                            className: "self-center whitespace-nowrap text-xl font-bold dark:text-white",
                            children: "My Portofolio"
                        })
                    }),
                    /*#__PURE__*/ jsx_runtime.jsx(external_flowbite_react_.Navbar.Toggle, {}),
                    /*#__PURE__*/ (0,jsx_runtime.jsxs)(external_flowbite_react_.Navbar.Collapse, {
                        children: [
                            /*#__PURE__*/ jsx_runtime.jsx(external_flowbite_react_.Navbar.Link, {
                                className: "text-base font-bold text-slate-600",
                                href: "/",
                                children: "Home"
                            }),
                            /*#__PURE__*/ jsx_runtime.jsx(external_flowbite_react_.Navbar.Link, {
                                className: "text-base font-bold text-slate-600",
                                href: "/project",
                                children: "Project"
                            }),
                            /*#__PURE__*/ jsx_runtime.jsx(external_flowbite_react_.Navbar.Link, {
                                className: "text-base font-bold text-slate-600",
                                href: "/about-me",
                                active: true,
                                children: "About Me"
                            })
                        ]
                    })
                ]
            }),
            /*#__PURE__*/ jsx_runtime.jsx("div", {
                className: "min-h-[calc(82.3vh-40px)]",
                children: /*#__PURE__*/ (0,jsx_runtime.jsxs)("div", {
                    className: "flex flex-wrap w-full mt-10",
                    children: [
                        /*#__PURE__*/ jsx_runtime.jsx("div", {
                            className: "w-full px-10 pb-10 md:pb-0 md:w-2/5",
                            children: /*#__PURE__*/ jsx_runtime.jsx("div", {
                                className: "w-full aspect-w-5 aspect-h-4",
                                children: /*#__PURE__*/ jsx_runtime.jsx("img", {
                                    src: "/img/blob_img_1.png",
                                    alt: "",
                                    className: ""
                                })
                            })
                        }),
                        /*#__PURE__*/ jsx_runtime.jsx("div", {
                            className: "w-full px-5 md:w-3/5",
                            children: /*#__PURE__*/ jsx_runtime.jsx("p", {
                                className: "text-xl md:text-2xl text-justify text-slate-800",
                                children: deskripsiDiriData.deskripsi_panjang
                            })
                        }),
                        /*#__PURE__*/ (0,jsx_runtime.jsxs)("div", {
                            className: "flex flex-wrap w-full mt-10",
                            children: [
                                /*#__PURE__*/ jsx_runtime.jsx("h2", {
                                    className: "text-4xl mx-auto font-bold text-slate-800 judul_segment mb-5",
                                    children: "Pendidikan"
                                }),
                                /*#__PURE__*/ jsx_runtime.jsx("div", {
                                    className: "w-full p-5",
                                    children: /*#__PURE__*/ jsx_runtime.jsx(external_flowbite_react_.Card, {
                                        className: "w-full",
                                        children: /*#__PURE__*/ jsx_runtime.jsx(external_flowbite_react_.Timeline, {
                                            children: pendidikanData.map((data)=>/*#__PURE__*/ (0,jsx_runtime.jsxs)(external_flowbite_react_.Timeline.Item, {
                                                    children: [
                                                        /*#__PURE__*/ jsx_runtime.jsx(external_flowbite_react_.Timeline.Point, {
                                                            icon: hi_namespaceObject.HiCalendar
                                                        }),
                                                        /*#__PURE__*/ (0,jsx_runtime.jsxs)(external_flowbite_react_.Timeline.Content, {
                                                            children: [
                                                                /*#__PURE__*/ (0,jsx_runtime.jsxs)(external_flowbite_react_.Timeline.Time, {
                                                                    children: [
                                                                        data.bulan_lulus,
                                                                        " ",
                                                                        data.tahun_lulus
                                                                    ]
                                                                }),
                                                                /*#__PURE__*/ (0,jsx_runtime.jsxs)(external_flowbite_react_.Timeline.Title, {
                                                                    className: "text-slate-700 py-1",
                                                                    children: [
                                                                        /*#__PURE__*/ jsx_runtime.jsx("span", {
                                                                            className: "font-bold",
                                                                            children: data.nama_sekolah
                                                                        }),
                                                                        /*#__PURE__*/ jsx_runtime.jsx("br", {}),
                                                                        /*#__PURE__*/ (0,jsx_runtime.jsxs)("span", {
                                                                            className: "text-base",
                                                                            children: [
                                                                                data.kualifikasi_studi,
                                                                                " in ",
                                                                                data.bidang_studi,
                                                                                " |",
                                                                                " ",
                                                                                data.negara_studi
                                                                            ]
                                                                        })
                                                                    ]
                                                                }),
                                                                /*#__PURE__*/ (0,jsx_runtime.jsxs)(external_flowbite_react_.Timeline.Body, {
                                                                    children: [
                                                                        /*#__PURE__*/ (0,jsx_runtime.jsxs)("div", {
                                                                            className: "flex flex-wrap font-semibold py-1",
                                                                            children: [
                                                                                /*#__PURE__*/ jsx_runtime.jsx("div", {
                                                                                    className: "w-full sm:w-1/5 text-slate-500",
                                                                                    children: "Jurusan"
                                                                                }),
                                                                                /*#__PURE__*/ jsx_runtime.jsx("div", {
                                                                                    className: "w-full sm:w-4/5 text-slate-700",
                                                                                    children: data.jurusan
                                                                                })
                                                                            ]
                                                                        }),
                                                                        /*#__PURE__*/ (0,jsx_runtime.jsxs)("div", {
                                                                            className: `${data.ipk ? "flex" : "hidden"} flex-wrap font-semibold py-1`,
                                                                            children: [
                                                                                /*#__PURE__*/ jsx_runtime.jsx("div", {
                                                                                    className: "w-full sm:w-1/5 text-slate-500",
                                                                                    children: "IPK / Nilai Akhir"
                                                                                }),
                                                                                /*#__PURE__*/ jsx_runtime.jsx("div", {
                                                                                    className: "w-full sm:w-4/5 text-slate-700",
                                                                                    children: data.ipk
                                                                                })
                                                                            ]
                                                                        }),
                                                                        /*#__PURE__*/ jsx_runtime.jsx("p", {
                                                                            className: "text-slate-700 whitespace-pre-line",
                                                                            children: data.informasi_tambahan
                                                                        })
                                                                    ]
                                                                })
                                                            ]
                                                        })
                                                    ]
                                                }, data.id))
                                        })
                                    })
                                })
                            ]
                        }),
                        /*#__PURE__*/ (0,jsx_runtime.jsxs)("div", {
                            className: "flex flex-wrap w-full mt-10",
                            children: [
                                /*#__PURE__*/ jsx_runtime.jsx("h2", {
                                    className: "text-4xl mx-auto font-bold text-slate-800 judul_segment mb-5",
                                    children: "Keahlian"
                                }),
                                /*#__PURE__*/ jsx_runtime.jsx("div", {
                                    className: "columns-1 sm:columns-2 lg:columns-3 gap-4 px-4 pt-5 my-5",
                                    children: keahlianData.map((data)=>/*#__PURE__*/ jsx_runtime.jsx("div", {
                                            className: "mb-4 break-inside-avoid",
                                            children: /*#__PURE__*/ (0,jsx_runtime.jsxs)(external_flowbite_react_.Card, {
                                                children: [
                                                    /*#__PURE__*/ jsx_runtime.jsx("a", {
                                                        href: "#",
                                                        children: /*#__PURE__*/ jsx_runtime.jsx("h5", {
                                                            className: "text-2xl font-bold tracking-tight text-slate-800 dark:text-white",
                                                            children: data.name
                                                        })
                                                    }),
                                                    /*#__PURE__*/ jsx_runtime.jsx("p", {
                                                        className: "text-slate-700",
                                                        children: data.deskripsi
                                                    })
                                                ]
                                            })
                                        }, data.id))
                                })
                            ]
                        }),
                        /*#__PURE__*/ (0,jsx_runtime.jsxs)("div", {
                            className: "flex flex-wrap w-full mt-10",
                            children: [
                                /*#__PURE__*/ jsx_runtime.jsx("h2", {
                                    className: "text-4xl mx-auto font-bold text-slate-800 judul_segment mb-5",
                                    children: "Skill"
                                }),
                                /*#__PURE__*/ jsx_runtime.jsx("div", {
                                    className: "flex flex-wrap gap-3 p-5",
                                    children: skillData.map((data)=>/*#__PURE__*/ (0,jsx_runtime.jsxs)("div", {
                                            className: "w-[calc(50%-6px)] p-5 md:w-[calc(33.33333%-8px)] lg:w-[calc(25%-10px)]",
                                            children: [
                                                /*#__PURE__*/ jsx_runtime.jsx(external_react_circular_progressbar_.CircularProgressbar, {
                                                    value: data.persentase,
                                                    text: `${data.persentase}%`
                                                }),
                                                /*#__PURE__*/ jsx_runtime.jsx("h3", {
                                                    className: "text-2xl md:text-3xl lg:text-4xl text-slate-700 text-center mt-4 font-semibold",
                                                    children: data.name
                                                })
                                            ]
                                        }, data.id))
                                })
                            ]
                        }),
                        /*#__PURE__*/ (0,jsx_runtime.jsxs)("div", {
                            className: "flex flex-wrap w-full mt-10",
                            children: [
                                /*#__PURE__*/ jsx_runtime.jsx("h2", {
                                    className: "text-4xl mx-auto font-bold text-slate-800 judul_segment mb-5",
                                    children: "Hubungi Saya"
                                }),
                                /*#__PURE__*/ (0,jsx_runtime.jsxs)("div", {
                                    className: "flex flex-wrap w-full gap-3 p-5",
                                    children: [
                                        /*#__PURE__*/ jsx_runtime.jsx(external_flowbite_react_.TextInput, {
                                            className: "w-full md:w-[calc(50%-6px)] text-lg font-semibold",
                                            id: "phone",
                                            required: true,
                                            readOnly: true,
                                            sizing: "lg",
                                            value: "081907398816",
                                            icon: io_namespaceObject.IoLogoWhatsapp,
                                            onClick: (e)=>{
                                                e.target.select();
                                            }
                                        }),
                                        /*#__PURE__*/ jsx_runtime.jsx(external_flowbite_react_.TextInput, {
                                            className: "w-full md:w-[calc(50%-6px)] text-lg font-semibold",
                                            id: "phone",
                                            required: true,
                                            readOnly: true,
                                            sizing: "lg",
                                            value: "darkmega007@gmail.com",
                                            icon: hi_namespaceObject.HiMail,
                                            onClick: (e)=>{
                                                e.target.select();
                                            }
                                        }),
                                        /*#__PURE__*/ jsx_runtime.jsx(external_flowbite_react_.TextInput, {
                                            className: "w-full md:w-[calc(50%-6px)] text-lg font-semibold",
                                            id: "phone",
                                            required: true,
                                            readOnly: true,
                                            sizing: "lg",
                                            value: "@hoseakeren",
                                            icon: io_namespaceObject.IoLogoInstagram,
                                            onClick: (e)=>{
                                                e.target.select();
                                            }
                                        }),
                                        /*#__PURE__*/ jsx_runtime.jsx(external_flowbite_react_.TextInput, {
                                            className: "w-full md:w-[calc(50%-6px)] text-lg font-semibold",
                                            id: "phone",
                                            required: true,
                                            readOnly: true,
                                            sizing: "lg",
                                            value: "hoseadikep",
                                            icon: io_namespaceObject.IoLogoLinkedin,
                                            onClick: (e)=>{
                                                e.target.select();
                                            }
                                        })
                                    ]
                                })
                            ]
                        })
                    ]
                })
            })
        ]
    });
}
async function getServerSideProps() {
    const API_CODE = "k0rY64IVQhjIN73JdOys8vqCNdcur4MEBjeLlwLR";
    const URL_SERVER = "http://127.0.0.1:8000";
    const resKeahlian = await fetch(`${URL_SERVER}/api/keahlian`, {
        method: "GET",
        cache: "no-store",
        headers: {
            Authorization: `Bearer ${API_CODE}`,
            Accept: `application/json`,
            "Content-Type": "application/json"
        }
    });
    const resSkill = await fetch(`${URL_SERVER}/api/skill`, {
        method: "GET",
        cache: "no-store",
        headers: {
            Authorization: `Bearer ${API_CODE}`,
            Accept: `application/json`,
            "Content-Type": "application/json"
        }
    });
    const resDeskripsiDiri = await fetch(`${URL_SERVER}/api/deskripsi-diri`, {
        method: "GET",
        cache: "no-store",
        headers: {
            Authorization: `Bearer ${API_CODE}`,
            Accept: `application/json`,
            "Content-Type": "application/json"
        }
    });
    const resPendidikan = await fetch(`${URL_SERVER}/api/pendidikan`, {
        method: "GET",
        cache: "no-store",
        headers: {
            Authorization: `Bearer ${API_CODE}`,
            Accept: `application/json`,
            "Content-Type": "application/json"
        }
    });
    const dataKeahlian = await resKeahlian.json();
    const dataSkill = await resSkill.json();
    const dataDeskripsiDiri = await resDeskripsiDiri.json();
    const dataPendidikan = await resPendidikan.json();
    // Pass data to the page via props
    return {
        props: {
            dataKeahlian,
            dataSkill,
            dataDeskripsiDiri,
            dataPendidikan
        }
    };
}


/***/ }),

/***/ 532:
/***/ ((module) => {

"use strict";
module.exports = require("flowbite-react");

/***/ }),

/***/ 968:
/***/ ((module) => {

"use strict";
module.exports = require("next/head");

/***/ }),

/***/ 689:
/***/ ((module) => {

"use strict";
module.exports = require("react");

/***/ }),

/***/ 400:
/***/ ((module) => {

"use strict";
module.exports = require("react-circular-progressbar");

/***/ })

};
;

// load runtime
var __webpack_require__ = require("../webpack-runtime.js");
__webpack_require__.C(exports);
var __webpack_exec__ = (moduleId) => (__webpack_require__(__webpack_require__.s = moduleId))
var __webpack_exports__ = __webpack_require__.X(0, [893], () => (__webpack_exec__(645)));
module.exports = __webpack_exports__;

})();