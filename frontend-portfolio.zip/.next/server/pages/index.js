(() => {
var exports = {};
exports.id = 405;
exports.ids = [405];
exports.modules = {

/***/ 485:
/***/ ((module) => {

// Exports
module.exports = {
	"style": {"fontFamily":"'__Nunito_b7da70', '__Nunito_Fallback_b7da70'","fontStyle":"normal"},
	"className": "__className_b7da70"
};


/***/ }),

/***/ 85:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (/* binding */ Home),
/* harmony export */   "getServerSideProps": () => (/* binding */ getServerSideProps)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(893);
/* harmony import */ var next_font_google_target_css_path_src_pages_index_tsx_import_Nunito_arguments_subsets_latin_variableName_nunito___WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(485);
/* harmony import */ var next_font_google_target_css_path_src_pages_index_tsx_import_Nunito_arguments_subsets_latin_variableName_nunito___WEBPACK_IMPORTED_MODULE_5___default = /*#__PURE__*/__webpack_require__.n(next_font_google_target_css_path_src_pages_index_tsx_import_Nunito_arguments_subsets_latin_variableName_nunito___WEBPACK_IMPORTED_MODULE_5__);
/* harmony import */ var flowbite_react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(532);
/* harmony import */ var flowbite_react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(flowbite_react__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var react_circular_progressbar__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(400);
/* harmony import */ var react_circular_progressbar__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(react_circular_progressbar__WEBPACK_IMPORTED_MODULE_3__);
/* harmony import */ var next_head__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(968);
/* harmony import */ var next_head__WEBPACK_IMPORTED_MODULE_4___default = /*#__PURE__*/__webpack_require__.n(next_head__WEBPACK_IMPORTED_MODULE_4__);






function Home({ dataKeahlian , dataSkill , dataDeskripsiDiri , dataProject  }) {
    const keahlianData = dataKeahlian.data;
    const skillData = dataSkill.data;
    const deskripsiDiriData = dataDeskripsiDiri.data;
    const projectData = dataProject.data;
    console.log("production");
    const percentage = 66;
    const [openModal, setOpenModal] = (0,react__WEBPACK_IMPORTED_MODULE_2__.useState)();
    return /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.Fragment, {
        children: [
            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)((next_head__WEBPACK_IMPORTED_MODULE_4___default()), {
                children: [
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("title", {
                        children: "Home | My Portfolio"
                    }),
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("meta", {
                        name: "description",
                        content: "My Portfolio adalah kumpulan dari project - project yang talah saya buat. Dan informasi tentang saya"
                    })
                ]
            }),
            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(flowbite_react__WEBPACK_IMPORTED_MODULE_1__.Navbar, {
                fluid: true,
                className: `w-full py-5 text-slate-700 ${(next_font_google_target_css_path_src_pages_index_tsx_import_Nunito_arguments_subsets_latin_variableName_nunito___WEBPACK_IMPORTED_MODULE_5___default().className)}`,
                children: [
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(flowbite_react__WEBPACK_IMPORTED_MODULE_1__.Navbar.Brand, {
                        href: "/",
                        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                            className: "self-center whitespace-nowrap text-xl font-bold dark:text-white",
                            children: "My Portofolio"
                        })
                    }),
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(flowbite_react__WEBPACK_IMPORTED_MODULE_1__.Navbar.Toggle, {}),
                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(flowbite_react__WEBPACK_IMPORTED_MODULE_1__.Navbar.Collapse, {
                        children: [
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(flowbite_react__WEBPACK_IMPORTED_MODULE_1__.Navbar.Link, {
                                className: "text-base font-bold text-slate-600",
                                href: "/",
                                active: true,
                                children: "Home"
                            }),
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(flowbite_react__WEBPACK_IMPORTED_MODULE_1__.Navbar.Link, {
                                className: "text-base font-bold text-slate-600",
                                href: "/project",
                                children: "Project"
                            }),
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(flowbite_react__WEBPACK_IMPORTED_MODULE_1__.Navbar.Link, {
                                className: "text-base font-bold text-slate-600",
                                href: "/about-me",
                                children: "About Me"
                            })
                        ]
                    })
                ]
            }),
            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                className: `min-h-[84.5vh] ${(next_font_google_target_css_path_src_pages_index_tsx_import_Nunito_arguments_subsets_latin_variableName_nunito___WEBPACK_IMPORTED_MODULE_5___default().className)}`,
                children: [
                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                        className: "flex flex-wrap bg-wave",
                        children: [
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                className: "w-full hidden md:block p-14 pb-0 md:w-2/5 md:pb-14 md:!pr-0 lg:py-28 lg:px-16",
                                children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                    className: "w-full aspect-w-4 aspect-h-3",
                                    children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("img", {
                                        src: "/img/blob_img_2.png",
                                        alt: "",
                                        className: ""
                                    })
                                })
                            }),
                            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                className: "w-full p-16 pt-10 sm:w-4/5 md:pt-16 md:w-3/5 lg:p-24",
                                children: [
                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("p", {
                                        className: "text-2xl text-white mb-3 font-semibold",
                                        children: "HALLO !"
                                    }),
                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("h2", {
                                        className: "text-3xl md:text-4xl lg:text-5xl text-white mb-4 font-semibold",
                                        children: "HOSEA DIKE PRASETYANTO, S.Kom."
                                    }),
                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("h2", {
                                        className: "text-4xl md:text-5xl lg:text-6xl text-white font-bold",
                                        children: "WEBSITE DEVELOPER"
                                    }),
                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                        className: "mt-16 h-16"
                                    })
                                ]
                            })
                        ]
                    }),
                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                        className: "flex flex-wrap w-full mt-10",
                        children: [
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                className: "w-full px-5 md:w-3/5",
                                children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("p", {
                                    className: "text-xl lg:text-2xl text-justify text-slate-800",
                                    children: deskripsiDiriData.deskripsi_singkat
                                })
                            }),
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                className: "w-full px-10 pt-16 md:pt-0 lg:px-16 md:w-2/5",
                                children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                    className: "w-full aspect-w-5 aspect-h-4",
                                    children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("img", {
                                        src: "/img/blob_img_1.png",
                                        alt: "",
                                        className: ""
                                    })
                                })
                            }),
                            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                className: "w-full mt-20",
                                children: [
                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("h2", {
                                        className: "text-4xl mx-auto font-bold text-slate-800 judul_segment",
                                        children: "Keahlian"
                                    }),
                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                        className: "columns-1 sm:columns-2 lg:columns-3 gap-4 px-4 pt-5 my-5",
                                        children: keahlianData.map((data)=>/*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                                className: "mb-4 break-inside-avoid",
                                                children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(flowbite_react__WEBPACK_IMPORTED_MODULE_1__.Card, {
                                                    children: [
                                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("a", {
                                                            href: "#",
                                                            children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("h5", {
                                                                className: "text-2xl font-bold tracking-tight text-slate-800 dark:text-white",
                                                                children: data.name
                                                            })
                                                        }),
                                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("p", {
                                                            className: "text-slate-700",
                                                            children: data.deskripsi
                                                        })
                                                    ]
                                                })
                                            }, data.id))
                                    })
                                ]
                            }),
                            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                className: "w-full mt-20",
                                children: [
                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("h2", {
                                        className: "text-4xl mx-auto font-bold text-slate-800 judul_segment",
                                        children: "Skill"
                                    }),
                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                        className: "flex flex-wrap justify-center gap-3 p-5",
                                        children: skillData.map((data)=>/*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                                className: "w-[calc(50%-6px)] p-5 md:w-[calc(33.33333%-8px)] lg:w-[calc(25%-10px)]",
                                                children: [
                                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(react_circular_progressbar__WEBPACK_IMPORTED_MODULE_3__.CircularProgressbar, {
                                                        value: data.persentase,
                                                        text: `${data.persentase}%`
                                                    }),
                                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("h3", {
                                                        className: "text-2xl md:text-3xl lg:text-4xl text-slate-700 text-center mt-4 font-semibold",
                                                        children: data.name
                                                    })
                                                ]
                                            }, data.id))
                                    })
                                ]
                            }),
                            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                className: "w-full mt-20",
                                children: [
                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("h2", {
                                        className: "text-4xl mx-auto font-bold text-slate-800 judul_segment",
                                        children: "Portofolio"
                                    }),
                                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                        className: "flex flex-wrap gap-3 p-5 justify-center",
                                        children: [
                                            projectData.map((data, index)=>/*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)((react__WEBPACK_IMPORTED_MODULE_2___default().Fragment), {
                                                    children: [
                                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                                            className: "w-full md:w-[calc(50%-6px)] lg:w-[calc(33.33333%-8px)]",
                                                            children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(flowbite_react__WEBPACK_IMPORTED_MODULE_1__.Card, {
                                                                onClick: ()=>setOpenModal("modal1"),
                                                                className: "cursor-pointer",
                                                                imgSrc: data.thumbnailProject,
                                                                children: [
                                                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("h5", {
                                                                        className: "text-2xl font-bold tracking-tight truncate text-slate-800 dark:text-white",
                                                                        children: data.namaProject
                                                                    }),
                                                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("p", {
                                                                        className: "text-slate-500 dark:text-gray-400 text-justify line-clamp-3",
                                                                        children: data.deskripsi
                                                                    }),
                                                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                                                        className: "flex flex-wrap gap-2",
                                                                        children: data.tagProject.map((data, index)=>/*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(flowbite_react__WEBPACK_IMPORTED_MODULE_1__.Badge, {
                                                                                color: "info",
                                                                                children: data
                                                                            }, index))
                                                                    })
                                                                ]
                                                            })
                                                        }),
                                                        /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(flowbite_react__WEBPACK_IMPORTED_MODULE_1__.Modal, {
                                                            dismissible: true,
                                                            show: openModal === "modal1",
                                                            onClose: ()=>setOpenModal(undefined),
                                                            size: "5xl",
                                                            className: "!inset-0 !h-screen modal-box",
                                                            children: [
                                                                /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(flowbite_react__WEBPACK_IMPORTED_MODULE_1__.Modal.Header, {
                                                                    children: [
                                                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("p", {
                                                                            className: "mb-2",
                                                                            children: data.namaProject
                                                                        }),
                                                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                                                            className: "flex flex-wrap gap-2",
                                                                            children: data.tagProject.map((data, index)=>/*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(flowbite_react__WEBPACK_IMPORTED_MODULE_1__.Badge, {
                                                                                    color: "info",
                                                                                    children: data
                                                                                }, index))
                                                                        })
                                                                    ]
                                                                }),
                                                                /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(flowbite_react__WEBPACK_IMPORTED_MODULE_1__.Modal.Body, {
                                                                    className: "portrait:h-[calc(80vh-35vw)] landscape:h-[calc(100vh-30vw)] lg:!h-[calc(100vh-20vw)] overflow-y-scroll",
                                                                    children: [
                                                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("h3", {
                                                                            className: "font-semibold text-slate-700 text-lg md:text-xl",
                                                                            children: "Deskripsi"
                                                                        }),
                                                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("p", {
                                                                            className: "text-base md:text-lg leading-relaxed mb-5 text-justify text-slate-500 dark:text-gray-400 whitespace-pre-line",
                                                                            children: data.deskripsi
                                                                        }),
                                                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("h3", {
                                                                            className: "font-semibold text-slate-700 text-lg md:text-xl",
                                                                            children: "Screenshot"
                                                                        }),
                                                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                                                            className: "mt-5 flex flex-wrap gap-3 justify-center",
                                                                            children: data.screenshoots.map((data, index)=>/*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                                                                    className: "w-full md:w-[calc(50%-6px)]",
                                                                                    children: [
                                                                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("h2", {
                                                                                            className: "font-semibold text-slate-700 text-base md:text-lg",
                                                                                            children: data.title
                                                                                        }),
                                                                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("p", {
                                                                                            className: "text-slate-700 text-sm md:text-base mb-4",
                                                                                            children: data.deskripsi
                                                                                        }),
                                                                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("img", {
                                                                                            src: data.img,
                                                                                            alt: data.title,
                                                                                            className: "shadow-xl rounded"
                                                                                        })
                                                                                    ]
                                                                                }))
                                                                        })
                                                                    ]
                                                                }),
                                                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(flowbite_react__WEBPACK_IMPORTED_MODULE_1__.Modal.Footer, {
                                                                    children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(flowbite_react__WEBPACK_IMPORTED_MODULE_1__.Button, {
                                                                        color: "gray",
                                                                        onClick: ()=>setOpenModal(undefined),
                                                                        children: "Oke"
                                                                    })
                                                                })
                                                            ]
                                                        })
                                                    ]
                                                }, index)),
                                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                                className: "w-full",
                                                children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("a", {
                                                    href: "/project",
                                                    className: "mx-auto mt-5 w-max block",
                                                    children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(flowbite_react__WEBPACK_IMPORTED_MODULE_1__.Button, {
                                                        outline: true,
                                                        gradientDuoTone: "cyanToBlue",
                                                        size: "lg",
                                                        children: "Semua Project"
                                                    })
                                                })
                                            })
                                        ]
                                    })
                                ]
                            })
                        ]
                    })
                ]
            })
        ]
    });
}
async function getServerSideProps() {
    const API_CODE = "k0rY64IVQhjIN73JdOys8vqCNdcur4MEBjeLlwLR";
    const URL_SERVER = "http://127.0.0.1:8000";
    const resKeahlian = await fetch(`${URL_SERVER}/api/keahlian`, {
        method: "GET",
        cache: "no-store",
        headers: {
            Authorization: `Bearer ${API_CODE}`,
            Accept: `application/json`,
            "Content-Type": "application/json"
        }
    });
    const resSkill = await fetch(`${URL_SERVER}/api/skill`, {
        method: "GET",
        cache: "no-store",
        headers: {
            Authorization: `Bearer ${API_CODE}`,
            Accept: `application/json`,
            "Content-Type": "application/json"
        }
    });
    const resDeskripsiDiri = await fetch(`${URL_SERVER}/api/deskripsi-diri`, {
        method: "GET",
        cache: "no-store",
        headers: {
            Authorization: `Bearer ${API_CODE}`,
            Accept: `application/json`,
            "Content-Type": "application/json"
        }
    });
    const resProject = await fetch(`${URL_SERVER}/api/project`, {
        method: "GET",
        cache: "no-store",
        headers: {
            Authorization: `Bearer ${API_CODE}`,
            Accept: `application/json`,
            "Content-Type": "application/json"
        }
    });
    const dataKeahlian = await resKeahlian.json();
    const dataSkill = await resSkill.json();
    const dataDeskripsiDiri = await resDeskripsiDiri.json();
    const dataProject = await resProject.json();
    // Pass data to the page via props
    return {
        props: {
            dataKeahlian,
            dataSkill,
            dataDeskripsiDiri,
            dataProject
        }
    };
}


/***/ }),

/***/ 532:
/***/ ((module) => {

"use strict";
module.exports = require("flowbite-react");

/***/ }),

/***/ 968:
/***/ ((module) => {

"use strict";
module.exports = require("next/head");

/***/ }),

/***/ 689:
/***/ ((module) => {

"use strict";
module.exports = require("react");

/***/ }),

/***/ 400:
/***/ ((module) => {

"use strict";
module.exports = require("react-circular-progressbar");

/***/ })

};
;

// load runtime
var __webpack_require__ = require("../webpack-runtime.js");
__webpack_require__.C(exports);
var __webpack_exec__ = (moduleId) => (__webpack_require__(__webpack_require__.s = moduleId))
var __webpack_exports__ = __webpack_require__.X(0, [893], () => (__webpack_exec__(85)));
module.exports = __webpack_exports__;

})();