"use strict";
(() => {
var exports = {};
exports.id = 660;
exports.ids = [660];
exports.modules = {

/***/ 157:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

// ESM COMPAT FLAG
__webpack_require__.r(__webpack_exports__);

// EXPORTS
__webpack_require__.d(__webpack_exports__, {
  "default": () => (/* binding */ Document)
});

// EXTERNAL MODULE: ./node_modules/react/jsx-runtime.js
var jsx_runtime = __webpack_require__(893);
// EXTERNAL MODULE: ./node_modules/next/document.js
var next_document = __webpack_require__(859);
// EXTERNAL MODULE: ./node_modules/next/font/google/target.css?{"path":"src\\components\\footer.jsx","import":"Nunito","arguments":[{"subsets":["latin"]}],"variableName":"nunito"}
var target_path_src_components_footer_jsx_import_Nunito_arguments_subsets_latin_variableName_nunito_ = __webpack_require__(272);
var target_path_src_components_footer_jsx_import_Nunito_arguments_subsets_latin_variableName_nunito_default = /*#__PURE__*/__webpack_require__.n(target_path_src_components_footer_jsx_import_Nunito_arguments_subsets_latin_variableName_nunito_);
// EXTERNAL MODULE: external "flowbite-react"
var external_flowbite_react_ = __webpack_require__(532);
;// CONCATENATED MODULE: ./src/components/footer.jsx



function Footer1() {
    return /*#__PURE__*/ jsx_runtime.jsx(jsx_runtime.Fragment, {
        children: /*#__PURE__*/ jsx_runtime.jsx(external_flowbite_react_.Footer, {
            container: true,
            className: `mt-16 ${(target_path_src_components_footer_jsx_import_Nunito_arguments_subsets_latin_variableName_nunito_default()).className}`,
            children: /*#__PURE__*/ (0,jsx_runtime.jsxs)("div", {
                className: "w-full text-center",
                children: [
                    /*#__PURE__*/ (0,jsx_runtime.jsxs)("div", {
                        className: "w-full justify-between sm:flex sm:items-center sm:justify-between",
                        children: [
                            /*#__PURE__*/ jsx_runtime.jsx("span", {
                                className: "self-center whitespace-nowrap text-xl font-bold text-slate-700 dark:text-white",
                                children: "My Portofolio"
                            }),
                            /*#__PURE__*/ (0,jsx_runtime.jsxs)(external_flowbite_react_.Footer.LinkGroup, {
                                className: "font-semibold gap-3",
                                children: [
                                    /*#__PURE__*/ jsx_runtime.jsx(external_flowbite_react_.Footer.Link, {
                                        href: "/",
                                        children: "Home"
                                    }),
                                    /*#__PURE__*/ jsx_runtime.jsx(external_flowbite_react_.Footer.Link, {
                                        href: "/project",
                                        children: "Project"
                                    }),
                                    /*#__PURE__*/ jsx_runtime.jsx(external_flowbite_react_.Footer.Link, {
                                        href: "/about-me",
                                        children: "About Me"
                                    })
                                ]
                            })
                        ]
                    }),
                    /*#__PURE__*/ jsx_runtime.jsx(external_flowbite_react_.Footer.Divider, {}),
                    /*#__PURE__*/ jsx_runtime.jsx(external_flowbite_react_.Footer.Copyright, {
                        href: "/",
                        by: "Hosea Dike",
                        year: new Date().getFullYear()
                    })
                ]
            })
        })
    });
}

;// CONCATENATED MODULE: ./src/pages/_document.tsx



function Document() {
    return /*#__PURE__*/ (0,jsx_runtime.jsxs)(next_document.Html, {
        lang: "en",
        children: [
            /*#__PURE__*/ jsx_runtime.jsx(next_document.Head, {}),
            /*#__PURE__*/ (0,jsx_runtime.jsxs)("body", {
                className: `!bg-neutral-50`,
                children: [
                    /*#__PURE__*/ (0,jsx_runtime.jsxs)("main", {
                        className: "max-w-screen-xl m-auto",
                        children: [
                            /*#__PURE__*/ jsx_runtime.jsx(next_document.Main, {}),
                            /*#__PURE__*/ jsx_runtime.jsx(Footer1, {})
                        ]
                    }),
                    /*#__PURE__*/ jsx_runtime.jsx(next_document.NextScript, {})
                ]
            })
        ]
    });
}


/***/ }),

/***/ 532:
/***/ ((module) => {

module.exports = require("flowbite-react");

/***/ }),

/***/ 140:
/***/ ((module) => {

module.exports = require("next/dist/server/get-page-files.js");

/***/ }),

/***/ 716:
/***/ ((module) => {

module.exports = require("next/dist/server/htmlescape.js");

/***/ }),

/***/ 368:
/***/ ((module) => {

module.exports = require("next/dist/server/utils.js");

/***/ }),

/***/ 724:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/constants.js");

/***/ }),

/***/ 743:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/html-context.js");

/***/ }),

/***/ 524:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/is-plain-object.js");

/***/ }),

/***/ 689:
/***/ ((module) => {

module.exports = require("react");

/***/ })

};
;

// load runtime
var __webpack_require__ = require("../webpack-runtime.js");
__webpack_require__.C(exports);
var __webpack_exec__ = (moduleId) => (__webpack_require__(__webpack_require__.s = moduleId))
var __webpack_exports__ = __webpack_require__.X(0, [893,228], () => (__webpack_exec__(157)));
module.exports = __webpack_exports__;

})();