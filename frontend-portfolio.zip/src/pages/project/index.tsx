import { Badge, Button, Card, Modal, Navbar } from "flowbite-react";
import React, { useState } from "react";
import { Nunito } from "next/font/google";
import Head from "next/head";

const nunito = Nunito({ subsets: ["latin"] });

export default function Home() {
  const [openModal, setOpenModal] = useState<string | undefined>();
  return (
    <>
      <Head>
        <title>Project | My Portfolio</title>
        <meta
          name="description"
          content="Kumpulan project yang telah saya buat"
        ></meta>
      </Head>

      <Navbar
        fluid={true}
        className={`w-full py-5 text-slate-700 ${nunito.className}`}
      >
        <Navbar.Brand href="/">
          {/* <img
            src="https://flowbite.com/docs/images/logo.svg"
            className="mr-3 h-6 sm:h-9"
            alt="Flowbite Logo"
          /> */}
          <span className="self-center whitespace-nowrap text-xl font-bold dark:text-white">
            My Portofolio
          </span>
        </Navbar.Brand>
        <Navbar.Toggle />
        <Navbar.Collapse>
          <Navbar.Link className="text-base font-bold text-slate-600" href="/">
            Home
          </Navbar.Link>
          <Navbar.Link
            className="text-base font-bold text-slate-600"
            href="/project"
            active={true}
          >
            Project
          </Navbar.Link>
          <Navbar.Link
            className="text-base font-bold text-slate-600"
            href="/about-me"
          >
            About Me
          </Navbar.Link>
        </Navbar.Collapse>
      </Navbar>

      <div className="min-h-[calc(82.3vh-40px)]">
        <div className="w-full mt-10">
          <h2 className="text-4xl mx-auto font-bold text-slate-800 judul_segment">
            Portofolio
          </h2>
          <div className="flex flex-wrap gap-3 p-5">
            <React.Fragment>
              <div className="w-full md:w-[calc(50%-6px)] lg:w-[calc(33.33333%-8px)]">
                <Card
                  onClick={() => setOpenModal("modal1")}
                  className="cursor-pointer"
                  imgSrc="https://flowbite.com/docs/images/blog/image-1.jpg"
                >
                  <h5 className="text-2xl font-bold tracking-tight truncate text-slate-800 dark:text-white">
                    Project 1
                  </h5>
                  <p className="text-slate-500 dark:text-gray-400 text-justify line-clamp-3">
                    Lorem ipsum dolor sit amet consectetur adipisicing elit. In,
                    nostrum sequi doloremque distinctio officiis sit laboriosam
                    modi id consequuntur, quae asperiores tenetur rerum ullam
                    placeat laborum ea eveniet esse voluptatibus?
                  </p>

                  <div className="flex flex-wrap gap-2">
                    <Badge color="info">React</Badge>
                    <Badge color="info">Laravel</Badge>
                    <Badge color="info">Tailwind</Badge>
                  </div>
                </Card>
              </div>
              <Modal
                dismissible={true}
                show={openModal === "modal1"}
                onClose={() => setOpenModal(undefined)}
                size="5xl"
                className="!inset-0 !h-screen modal-box"
              >
                <Modal.Header>
                  <h3 className="mb-2">Project 1</h3>

                  <div className="flex flex-wrap gap-2">
                    <Badge color="info">React</Badge>
                    <Badge color="info">Laravel</Badge>
                    <Badge color="info">Tailwind</Badge>
                  </div>
                </Modal.Header>
                <Modal.Body className="portrait:h-[calc(80vh-35vw)] landscape:h-[calc(100vh-30vw)] lg:!h-[calc(100vh-20vw)] overflow-y-scroll">
                  <h3 className="font-semibold text-slate-700 text-lg md:text-xl">
                    Deskripsi
                  </h3>
                  <p className="text-base md:text-lg leading-relaxed mb-5 text-justify text-slate-500 dark:text-gray-400">
                    Lorem ipsum dolor sit amet consectetur adipisicing elit. In,
                    nostrum sequi doloremque distinctio officiis sit laboriosam
                    modi id consequuntur, quae asperiores tenetur rerum ullam
                    placeat laborum ea eveniet esse voluptatibus? Lorem ipsum
                    dolor sit amet consectetur adipisicing elit. In, nostrum
                    sequi doloremque distinctio officiis sit laboriosam modi id
                    consequuntur, quae asperiores tenetur rerum ullam placeat
                    laborum ea eveniet esse voluptatibus?
                  </p>
                  <h3 className="font-semibold text-slate-700 text-lg md:text-xl">
                    Screenshot
                  </h3>
                  <div className="mt-5 flex flex-wrap gap-3 justify-center">
                    <div className="w-full md:w-[calc(50%-6px)]">
                      <h2 className="font-semibold text-slate-700 text-base md:text-lg">
                        Frontend | Halaman Home
                      </h2>
                      <p className="text-slate-700 text-sm md:text-base mb-4">
                        Lorem ipsum dolor sit amet, consectetur adipisicing
                        elit. Vero sunt sapiente hic repudiandae et incidunt
                        error sequi, dicta vel. Porro, quisquam dolor earum vel
                        alias ab dolores aperiam ratione nemo.
                      </p>
                      <img
                        src="https://flowbite.com/docs/images/blog/image-1.jpg"
                        alt=""
                      />
                    </div>
                    <div className="w-full md:w-[calc(50%-6px)]">
                      <h2 className="font-semibold text-slate-700 text-base md:text-lg">
                        Halaman 2
                      </h2>
                      <p className="text-slate-700 text-sm md:text-base mb-4">
                        Lorem ipsum dolor sit amet, consectetur adipisicing
                        elit. Vero sunt sapiente hic repudiandae et incidunt
                        error sequi, dicta vel. Porro, quisquam dolor earum vel
                        alias ab dolores aperiam ratione nemo.
                      </p>
                      <img
                        src="https://flowbite.com/docs/images/blog/image-1.jpg"
                        alt=""
                      />
                    </div>
                    <div className="w-full md:w-[calc(50%-6px)]">
                      <h2 className="font-semibold text-slate-700 text-base md:text-lg">
                        Halaman 3
                      </h2>
                      <p className="text-slate-700 text-sm md:text-base mb-4">
                        Lorem ipsum dolor sit amet, consectetur adipisicing
                        elit. Vero sunt sapiente hic repudiandae et incidunt
                        error sequi, dicta vel. Porro, quisquam dolor earum vel
                        alias ab dolores aperiam ratione nemo.
                      </p>
                      <img
                        src="https://flowbite.com/docs/images/blog/image-1.jpg"
                        alt=""
                      />
                    </div>
                  </div>
                </Modal.Body>
                <Modal.Footer>
                  <Button color="gray" onClick={() => setOpenModal(undefined)}>
                    Oke
                  </Button>
                </Modal.Footer>
              </Modal>
            </React.Fragment>
            <React.Fragment>
              <div className="w-full md:w-[calc(50%-6px)] lg:w-[calc(33.33333%-8px)]">
                <Card
                  onClick={() => setOpenModal("modal2")}
                  className="cursor-pointer"
                  imgSrc="https://flowbite.com/docs/images/blog/image-1.jpg"
                >
                  <h5 className="text-2xl font-bold tracking-tight truncate text-slate-800 dark:text-white">
                    Project 2
                  </h5>
                  <p className="text-slate-500 dark:text-gray-400 text-justify line-clamp-3">
                    Lorem ipsum dolor sit amet consectetur adipisicing elit. In,
                    nostrum sequi doloremque distinctio officiis sit laboriosam
                    modi id consequuntur, quae asperiores tenetur rerum ullam
                    placeat laborum ea eveniet esse voluptatibus?
                  </p>

                  <div className="flex flex-wrap gap-2">
                    <Badge color="info">React</Badge>
                    <Badge color="info">Laravel</Badge>
                    <Badge color="info">Tailwind</Badge>
                  </div>
                </Card>
              </div>
              <Modal
                dismissible={true}
                show={openModal === "modal2"}
                onClose={() => setOpenModal(undefined)}
                size="5xl"
                className="!inset-0 !h-screen modal-box"
              >
                <Modal.Header>
                  <h3 className="mb-2">Project 2</h3>

                  <div className="flex flex-wrap gap-2">
                    <Badge color="info">React</Badge>
                    <Badge color="info">Laravel</Badge>
                    <Badge color="info">Tailwind</Badge>
                  </div>
                </Modal.Header>
                <Modal.Body className="portrait:h-[calc(80vh-35vw)] landscape:h-[calc(100vh-30vw)] lg:!h-[calc(100vh-20vw)] overflow-y-scroll">
                  <h3 className="font-semibold text-slate-700 text-lg md:text-xl">
                    Deskripsi
                  </h3>
                  <p className="text-base md:text-lg leading-relaxed mb-5 text-justify text-slate-500 dark:text-gray-400">
                    Lorem ipsum dolor sit amet consectetur adipisicing elit. In,
                    nostrum sequi doloremque distinctio officiis sit laboriosam
                    modi id consequuntur, quae asperiores tenetur rerum ullam
                    placeat laborum ea eveniet esse voluptatibus? Lorem ipsum
                    dolor sit amet consectetur adipisicing elit. In, nostrum
                    sequi doloremque distinctio officiis sit laboriosam modi id
                    consequuntur, quae asperiores tenetur rerum ullam placeat
                    laborum ea eveniet esse voluptatibus?
                  </p>
                  <h3 className="font-semibold text-slate-700 text-lg md:text-xl">
                    Screenshot
                  </h3>
                  <div className="mt-5 flex flex-wrap gap-3 justify-center">
                    <div className="w-full md:w-[calc(50%-6px)]">
                      <h2 className="font-semibold text-slate-700 text-base md:text-lg">
                        Halaman 1
                      </h2>
                      <p className="text-slate-700 text-sm md:text-base mb-4">
                        Lorem ipsum dolor sit amet, consectetur adipisicing
                        elit. Vero sunt sapiente hic repudiandae et incidunt
                        error sequi, dicta vel. Porro, quisquam dolor earum vel
                        alias ab dolores aperiam ratione nemo.
                      </p>
                      <img
                        src="https://flowbite.com/docs/images/blog/image-1.jpg"
                        alt=""
                      />
                    </div>
                    <div className="w-full md:w-[calc(50%-6px)]">
                      <h2 className="font-semibold text-slate-700 text-base md:text-lg">
                        Halaman 2
                      </h2>
                      <p className="text-slate-700 text-sm md:text-base mb-4">
                        Lorem ipsum dolor sit amet, consectetur adipisicing
                        elit. Vero sunt sapiente hic repudiandae et incidunt
                        error sequi, dicta vel. Porro, quisquam dolor earum vel
                        alias ab dolores aperiam ratione nemo.
                      </p>
                      <img
                        src="https://flowbite.com/docs/images/blog/image-1.jpg"
                        alt=""
                      />
                    </div>
                    <div className="w-full md:w-[calc(50%-6px)]">
                      <h2 className="font-semibold text-slate-700 text-base md:text-lg">
                        Halaman 3
                      </h2>
                      <p className="text-slate-700 text-sm md:text-base mb-4">
                        Lorem ipsum dolor sit amet, consectetur adipisicing
                        elit. Vero sunt sapiente hic repudiandae et incidunt
                        error sequi, dicta vel. Porro, quisquam dolor earum vel
                        alias ab dolores aperiam ratione nemo.
                      </p>
                      <img
                        src="https://flowbite.com/docs/images/blog/image-1.jpg"
                        alt=""
                      />
                    </div>
                  </div>
                </Modal.Body>
                <Modal.Footer>
                  <Button color="gray" onClick={() => setOpenModal(undefined)}>
                    Oke
                  </Button>
                </Modal.Footer>
              </Modal>
            </React.Fragment>
            <React.Fragment>
              <div className="w-full md:w-[calc(50%-6px)] lg:w-[calc(33.33333%-8px)]">
                <Card
                  onClick={() => setOpenModal("modal3")}
                  className="cursor-pointer"
                  imgSrc="https://flowbite.com/docs/images/blog/image-1.jpg"
                >
                  <h5 className="text-2xl font-bold tracking-tight truncate text-slate-800 dark:text-white">
                    Project 3
                  </h5>
                  <p className="text-slate-500 dark:text-gray-400 text-justify line-clamp-3">
                    Lorem ipsum dolor sit amet consectetur adipisicing elit. In,
                    nostrum sequi doloremque distinctio officiis sit laboriosam
                    modi id consequuntur, quae asperiores tenetur rerum ullam
                    placeat laborum ea eveniet esse voluptatibus?
                  </p>

                  <div className="flex flex-wrap gap-2">
                    <Badge color="info">React</Badge>
                    <Badge color="info">Laravel</Badge>
                    <Badge color="info">Tailwind</Badge>
                  </div>
                </Card>
              </div>
              <Modal
                dismissible={true}
                show={openModal === "modal3"}
                onClose={() => setOpenModal(undefined)}
                size="5xl"
                className="!inset-0 !h-screen modal-box"
              >
                <Modal.Header>
                  <h3 className="mb-2">Project 3</h3>

                  <div className="flex flex-wrap gap-2">
                    <Badge color="info">React</Badge>
                    <Badge color="info">Laravel</Badge>
                    <Badge color="info">Tailwind</Badge>
                  </div>
                </Modal.Header>
                <Modal.Body className="portrait:h-[calc(80vh-35vw)] landscape:h-[calc(100vh-30vw)] lg:!h-[calc(100vh-20vw)] overflow-y-scroll">
                  <h3 className="font-semibold text-slate-700 text-lg md:text-xl">
                    Deskripsi
                  </h3>
                  <p className="text-base md:text-lg leading-relaxed mb-5 text-justify text-slate-500 dark:text-gray-400">
                    Lorem ipsum dolor sit amet consectetur adipisicing elit. In,
                    nostrum sequi doloremque distinctio officiis sit laboriosam
                    modi id consequuntur, quae asperiores tenetur rerum ullam
                    placeat laborum ea eveniet esse voluptatibus? Lorem ipsum
                    dolor sit amet consectetur adipisicing elit. In, nostrum
                    sequi doloremque distinctio officiis sit laboriosam modi id
                    consequuntur, quae asperiores tenetur rerum ullam placeat
                    laborum ea eveniet esse voluptatibus?
                  </p>
                  <h3 className="font-semibold text-slate-700 text-lg md:text-xl">
                    Screenshot
                  </h3>
                  <div className="mt-5 flex flex-wrap gap-3 justify-center">
                    <div className="w-full md:w-[calc(50%-6px)]">
                      <h2 className="font-semibold text-slate-700 text-base md:text-lg">
                        Halaman 1
                      </h2>
                      <p className="text-slate-700 text-sm md:text-base mb-4">
                        Lorem ipsum dolor sit amet, consectetur adipisicing
                        elit. Vero sunt sapiente hic repudiandae et incidunt
                        error sequi, dicta vel. Porro, quisquam dolor earum vel
                        alias ab dolores aperiam ratione nemo.
                      </p>
                      <img
                        src="https://flowbite.com/docs/images/blog/image-1.jpg"
                        alt=""
                      />
                    </div>
                    <div className="w-full md:w-[calc(50%-6px)]">
                      <h2 className="font-semibold text-slate-700 text-base md:text-lg">
                        Halaman 2
                      </h2>
                      <p className="text-slate-700 text-sm md:text-base mb-4">
                        Lorem ipsum dolor sit amet, consectetur adipisicing
                        elit. Vero sunt sapiente hic repudiandae et incidunt
                        error sequi, dicta vel. Porro, quisquam dolor earum vel
                        alias ab dolores aperiam ratione nemo.
                      </p>
                      <img
                        src="https://flowbite.com/docs/images/blog/image-1.jpg"
                        alt=""
                      />
                    </div>
                    <div className="w-full md:w-[calc(50%-6px)]">
                      <h2 className="font-semibold text-slate-700 text-base md:text-lg">
                        Halaman 3
                      </h2>
                      <p className="text-slate-700 text-sm md:text-base mb-4">
                        Lorem ipsum dolor sit amet, consectetur adipisicing
                        elit. Vero sunt sapiente hic repudiandae et incidunt
                        error sequi, dicta vel. Porro, quisquam dolor earum vel
                        alias ab dolores aperiam ratione nemo.
                      </p>
                      <img
                        src="https://flowbite.com/docs/images/blog/image-1.jpg"
                        alt=""
                      />
                    </div>
                  </div>
                </Modal.Body>
                <Modal.Footer>
                  <Button color="gray" onClick={() => setOpenModal(undefined)}>
                    Oke
                  </Button>
                </Modal.Footer>
              </Modal>
            </React.Fragment>
          </div>
        </div>
      </div>
    </>
  );
}
